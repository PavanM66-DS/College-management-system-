package com.cms.entity;

public class total {
	
	public int getNtimes() {
		return ntimes;
	}
	public void setNtimes(int ntimes) {
		this.ntimes = ntimes;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	private int ntimes ;
	private int percentage ;

}
