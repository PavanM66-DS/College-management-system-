package com.cms.entity;

import java.util.List;

public class attendanceform {
	
	

	public List<Attendance> getAttendaces() {
		return attendaces;
	}

	public void setAttendaces(List<Attendance> attendaces) {
		this.attendaces = attendaces;
	}

	private List<Attendance> attendaces;

}
