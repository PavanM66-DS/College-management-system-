# collage-management-system (Gradution Project)

This is a software system developed for a college for maintaining information
related to various daily activities in the college.
The CMIS is used to maintain details of various departments in the college,
various courses offered by the college, Faculty details,  student
admission details, day-to-day attendance details, exams and so on.
College Management System is a web based application in which users can
access anywhere anytime.
College Management System has a REST api can be consumed via Android or IOS application
this is helpful for students as well as the professors .
The main point in our project is replacing the paper work and time consuming processes
between the three elements of the college (students , professors and courses) to an online operations save time and effort , So info can
be gotten easily and rapidly. 
-----------------------------------------------------------------------------
used technologies :
java EE , spring boot , spring mvc , spring data JPA , hibernate , jsp , mysql 
